# DOMINOS CLUB — Android WebView Project

**الإصدار:** 11.7.5.7  
**المالك/الكريتورز:** Adam Mostafa

## ما يتضمنه المشروع
- نسخة HTML المحدثة داخل `app/src/main/assets/index.html`.
- تطبيق Android أصلي بسيط يستخدم WebView أفقيًا.
- يحتفظ بعنوان الأصل `https://unique-culotte-sc0b5.ship.place/` عند تحميل HTML محليًا بواسطة `loadDataWithBaseURL` حتى لا يتغير أصل الويب المستخدم مع Firebase.
- تفعيل JavaScript وDOM Storage وملفات تعريف الارتباط لدعم Firebase.
- صلاحية الميكروفون اختيارية لدعم دردشة الصوت في الغرفة.
- لا يحتوي المشروع على إعداد Firebase جديد، ولا يغيّر مفاتيح المشروع أو قواعد Realtime Database.

## بناء APK
1. افتح مجلد المشروع `DOMINOS_CLUB_ANDROID_PROJECT` في Android Studio على كمبيوتر.
2. وافق على تثبيت Android SDK Platform 35 وأدوات Android Gradle المطلوبة.
3. اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. ملف APK التجريبي سيظهر عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظة مهمة عن Firebase
تم إبقاء أصل الموقع نفسه في WebView بدل استخدام `file://` أو `localhost`. هذا يقلل احتمال تغيير نطاق المصادقة المصرّح به. مع ذلك يجب تجربة تسجيل الدخول وإنشاء غرفة من جهازين بعد بناء APK؛ لا يمكن اعتبار اتصال Firebase داخل WebView مختبرًا فعليًا قبل هذه التجربة.

## تفاصيل البناء
- Package: `com.dominosclub.app`
- Version name: `11.7.5.7`
- Min SDK: 23
- Target SDK: 34
- Orientation: landscape

هذا مجلد مشروع Android Studio وليس APK جاهزًا. بيئة الإنشاء الحالية لا تحتوي على Android SDK أو Gradle ولا يمكنها تنزيل حزم البناء، لذلك لم يتم توليد ملف APK ثنائي هنا.
